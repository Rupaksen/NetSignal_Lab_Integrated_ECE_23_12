const express=require("express"),path=require("path");
const app=express(),PORT=process.env.PORT||3000;
app.use(express.json());
app.use(express.static(path.join(__dirname,"../frontend")));
app.get("/api/health",(req,res)=>res.json({status:"ok",service:"NetSignal Lab",time:new Date().toISOString()}));
app.post("/api/validate",(req,res)=>{const e=String(req.body?.equation||"").trim(),ok=/^[0-9a-zA-Z_+*/^().,\s\-]+$/.test(e)&&!/constructor|prototype|__proto__|globalThis|window|document|Function|eval/i.test(e);res.json({valid:ok,equation:e,error:ok?null:"Unsupported or unsafe equation"});});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../frontend/index.html")));
app.listen(PORT,()=>console.log(`NetSignal Lab: http://localhost:${PORT}`));