# NetSignal Lab — Integrated 4G/5G + Signal Sampling & Quantization

This combines the previous 4G/5G speed optimizer with the new DSP signal module in one red/black full-stack application.

## Run
cd backend
npm install
npm start

Open http://localhost:3000

## Modules
1. 4G/5G Analyzer
- Simulated download/upload, ping, packet loss
- RSRP/RSRQ/SINR profiles
- live throughput graph
- quality score and recommendations
- Start / Stop / Reset

2. Signal Lab
- equation input
- continuous numerical waveform
- sampling at t=n/Fs
- Nyquist calculation
- 2–16 bit uniform mid-rise quantization
- exact quantization levels and binary codes
- error, MSE, SNR
- CSV export

No external API is required. The cellular module is a browser simulator because normal web pages cannot directly access the device modem.